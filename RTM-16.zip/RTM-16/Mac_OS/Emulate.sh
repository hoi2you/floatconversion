#!/usr/bin/env zsh

python3 ./Tools/Emulator/Emulator.py ./mc/$1.mc ./mc/OS.mc

