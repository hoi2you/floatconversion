from PIL import Image

# Open the PNG file
image = Image.open("test.png")

# Access basic information about the image
width, height = image.size
format = image.format
mode = image.mode

print(f"Image width: {width}")
print(f"Image height: {height}")
print(f"Image format: {format}")
print(f"Image mode: {mode}")

# Convert image to 16-bit color format
converted_image = image.convert("RGB")
pixels = list(converted_image.getdata())

converted_pixels = []
for pixel in pixels:
    red = pixel[0]
    green = pixel[1]
    blue = pixel[2]

    # Convert to 5-bit Red channel
    red_5bit = (red >> 3) & 0x1F

    # Convert to 6-bit Green channel
    green_6bit = (green >> 2) & 0x3F

    # Convert to 5-bit Blue channel
    blue_5bit = (blue >> 3) & 0x1F

    # Combine the channels into a 16-bit color value
    color_16bit = (red_5bit << 11) | (green_6bit << 5) | blue_5bit

    converted_pixels.append(color_16bit)

# Save the converted image as test.rgb
with open("test.rgb", mode="wb") as f_out:
    for pixel in converted_pixels:
        col_hi = (pixel & 0xFF00) >> 8
        col_lo = pixel & 0x00FF

        f_out.write(col_hi.to_bytes(1, 'big'))
        f_out.write(col_lo.to_bytes(1, 'big'))

print("Conversion completed and saved as test.rgb.")
