
import json
import os
import platform

# Define the list of control signals in bit order (MSB to LSB)
control_signals = [
    "REGA_E", "REGB_E", "FPU_E", "IND_E", "STACK_E", "FLAG_E", "CACHE_E", "CNTRL_E",
    "IAR_E", "IR_E", "ACC_E", "BUS1", "ALU3", "ALU2", "ALU1", "ALU0",
    "ALU_E", "MAR_S", "ACC_S", "IR_S", "IAR_S", "CNTRL_S", "TMP_S", "CACHE_S",
    "FLAGS_S", "STACK_S", "INDEX_S", "FPU_S", "STOP", "END", "REGA_S", "REGB_S"
]

def validate_microcode():
    errors_found = False
    for instr, modes in microcode_dict.items():
        for mode, steps in modes.items():
            for step in steps:
                if len(step) != 8 or not all(c in '0123456789ABCDEFabcdef' for c in step):
                    print(f"Invalid step '{step}' in instruction {instr}, mode {mode}")
                    errors_found = True
    return not errors_found

# Load microcode from file at the start
try:
    with open('Microcode.json', 'r') as f:
        microcode_dict = json.load(f)
    if not validate_microcode():
        print("Warning: Some microcode entries are invalid!")    
except Exception as e:
    print(f'Error importing Microcode.json: {e}')
    print('Starting with empty microcode dictionary...')
    microcode_dict = {}

dict_changed = False  # Track changes for saving prompt

def list_instructions():
    print('\nAvailable Instructions and Addressing Modes:')
    for instr in sorted(microcode_dict):
        modes = sorted(microcode_dict[instr].keys(), key=int)
        mode_labels = []
        for mode in modes:
            steps = microcode_dict[instr][mode]
            if not steps:
                label = 'E'
            elif steps == ['00000008']:
                label = 'S'
            else:
                label = str(mode)
            mode_labels.append(label)
        print(f'  {instr}: modes [{" ".join(mode_labels)}]')
    print()

def edit_microcode_control(instr, mode, index, *signals):
    global dict_changed
    instr = instr.upper()
    bitfield = ['0'] * 32
    signal_set = set(signals)

    # Build binary representation
    for i, name in enumerate(control_signals):
        if name in signal_set:
            bitfield[i] = '1'

    bin_string = ''.join(bitfield)
    hex_value = f"{int(bin_string, 2):08X}"

    try:
        steps = microcode_dict[instr][str(mode)]
        while len(steps) <= index:
            steps.append('00000000')
        steps[index] = hex_value
        dict_changed = True
        print(f"Updated {instr} mode {mode} step {index} to {hex_value} from control signals.")
    except KeyError:
        print("Instruction or mode not found.")

def view_microcode(instr, mode):
    instr = instr.upper()
    try:
        steps = microcode_dict[instr][str(mode)]
        if not steps:
            print(f'{mode}: E')
            return
        print(f'{mode}: ', end='')
        for step in steps:
            print(f'{step} ', end='')
        print()
    except KeyError:
        print('Instruction or mode not found.')

def edit_microcode(instr, mode, index, new_value):
    global dict_changed
    instr = instr.upper()
    try:
        if len(new_value) != 8 or not all(c in '0123456789ABCDEFabcdef' for c in new_value):
            print('New value must be 8 hex characters.')
            return
        steps = microcode_dict[instr][str(mode)]
        while len(steps) <= index:
            steps.append('00000000')
        steps[index] = new_value.upper()
        print(f'Updated {instr}, mode {mode}, step {index} to {new_value.upper()}')
        dict_changed = True
        if not validate_microcode():
            print("Warning: Some microcode entries are invalid! Files will still be saved.")
    except KeyError:
        print('Instruction or mode not found.')
    except IndexError:
        print('Invalid microcode step index.')

def delete_microcode(instr, mode, index):
    global dict_changed
    instr = instr.upper()
    try:
        steps = microcode_dict[instr][str(mode)]
        if 0 <= index < len(steps):
            removed = steps.pop(index)
            print(f'Removed step {index} from {instr}, mode {mode} (was {removed})')
            dict_changed = True
        else:
            print('Invalid index to delete.')
    except KeyError:
        print('Instruction or mode not found.')

def export_control_signal_table():
    import pandas as pd
    headers = [
        "REGA_E", "REGB_E", "FPU_E", "IND_E", "STACK_E", "FLAG_E", "CACHE_S", "CNTRL_E",
        "IAR_E", "IR_E", "ACC_E", "BUS1", "ALU3", "ALU2", "ALU1", "ALU0",
        "ALU_E", "MAR_S", "ACC_S", "IR_S", "IAR_S", "CNTRL_S", "TMP_S", "CACHE_E",
        "FLAGS_S", "STACK_S", "INDEX_S", "FPU_S", "STOP", "END", "REGA_S", "REGB_S",
        "HEX OUTPUT"
    ]
    mode_map = {'0': '00', '1': '01', '2': '10', '3': '11'}
    rows = []

    instr_order = list(microcode_dict.keys())

    for instr in instr_order:
        for mode in ['0', '1', '2', '3']:
            steps = microcode_dict[instr].get(mode, [])
            for hex_val in steps:
                try:
                    bin_val = f"{int(hex_val, 16):032b}"
                    bit_list = list(bin_val)
                    bit_list.append(hex_val.upper())
                    row = [instr.lower(), mode_map[mode]] + bit_list
                    rows.append(row)
                except ValueError:
                    rows.append([instr.lower(), mode_map[mode], "INVALID_HEX", hex_val])

    with open("ControlSignalTable.txt", "w") as f:
        f.write('\t'.join(["Command", "ADDR_M"] + headers) + '\n')
        for row in rows:
            f.write('\t'.join(row) + '\n')

    import pandas as pd
    df = pd.DataFrame(rows, columns=["Command", "ADDR_M"] + headers)
    df.to_excel("ControlSignalTable.xlsx", index=False)

    print("Exported ControlSignalTable.txt and ControlSignalTable.xlsx")

def save_all():
    global dict_changed

    if not validate_microcode():
        print("Warning: Some microcode entries are invalid! Files will still be saved.")

    # Flatten microcode
    hex_flat = []
    sequencer = []
    counter = 0

    for instr in microcode_dict:
        for mode in ['0', '1', '2', '3']:
            steps = microcode_dict[instr].get(mode, [])
            for word in steps:
                hex_flat.append(word)
            if steps:
                sequencer.append(f'{counter:03X}')
                counter += len(steps)

    total_values = len(hex_flat)
    required_values = 64 * 16
    if total_values < required_values:
        hex_flat.extend(['00000000'] * (required_values - total_values))

    with open('Microcode.uc', 'w') as f:
        f.write('v3.0 hex words addressed\n')
        for i in range(0, len(hex_flat), 8):
            line = ' '.join(hex_flat[i:i+8])
            f.write(f'{i:03x}: {line}\n')

    with open('MicrocodeLUT.uc', 'w') as f:
        f.write('v3.0 hex words addressed\n')
        for i in range(0, len(sequencer), 16):
            row = sequencer[i:i+16]
            f.write(f'{i:02x}: {" ".join(row)}\n')

    with open('Microcode.json', 'w') as f:
        json.dump(microcode_dict, f, indent=2)

    dict_changed = False
    print("Changes saved.")

def simulate_microcode(instr, mode):
    instr = instr.upper()
    try:
        steps = microcode_dict[instr][str(mode)]
        print(f"\nInstruction: {instr} {mode}")
        print("╔═════════╦════════════════════════════════════════════════════════════════════╗")
        for i, hex_val in enumerate(steps):
            bin_val = f"{int(hex_val, 16):032b}"
            active = [name for bit, name in zip(bin_val, control_signals) if bit == '1']
            signal_str = "".join(f"{signal:<10}" for signal in active)
            print(f"║ Step {i:<2} ║ {signal_str:<67}║")
        print("╚═════════╩════════════════════════════════════════════════════════════════════╝")
    except KeyError:
        print(f"Instruction '{instr}' or mode '{mode}' not found.")

def inspect_hex_value(hex_value):
    if len(hex_value) != 8 or not all(c in '0123456789ABCDEFabcdef' for c in hex_value):
        print("Input must be a valid 8-character hex value.")
        return

    try:
        bin_val = f"{int(hex_value, 16):032b}"
    except ValueError:
        print("Invalid hex value.")
        return

    active = [name for bit, name in zip(bin_val, control_signals) if bit == '1']

    print(f"\nHex: {hex_value.upper()}")
    print(f"Bin: {bin_val}")
    if active:
        signals_line = '   '.join(active)
        print(f"Active Control Signals:  {signals_line}")
    else:
        print("Active Control Signals:  None")

def show_help():
    print('''
Available Commands:
  list                                  - Show all instructions and their addressing modes
  view INSTR MODE                       - View microcode steps (Example: view add 0)
  edit INSTR MODE INDEX NEWVAL          - Change a step (Example: edit add 0 2 12345678)
  delete INSTR MODE INDEX               - Delete a microcode step (Example: delete add 0 2)
  addinstr INSTR                        - Add a new instruction with empty modes 0–3
  delinstr INSTR                        - Delete an entire instruction
  table                                 - Export control signal table as .txt and .xlsx
  validate                              - Check all instructions for formatting errors
  microsteps INSTR MODE                 - Show all control lines for microsteps
  editcontrol INSTR MODE INDEX SIGNALS  - Edit step by specifying control signals (e.g. editcontrol add 0 0 IAR_E ACC_E BUS1)
  inspect HEXVAL                        - Show which control signals are active in a hex word
  save                                  - Save Microcode.json, .uc, and LUT files
  quit                                  - Save and exit the editor
  cls / clear                           - Clear the terminal screen
  help                                  - Show this help message
''')

# Start with a clean terminal
if platform.system() == 'Windows':
    os.system('cls')
else:
    os.system('clear')

print('\nMicrocode Editor')
print('\nPlease make a copy of your original Microcode.json file before editing !!!')
show_help()

# CLI loop
while True:
    try:
        cmd = input('CLI> ').strip().lower()
    except (EOFError, KeyboardInterrupt):
        break
    if not cmd:
        continue
    parts = cmd.split()

    if parts[0] == 'list':
        list_instructions()
    elif parts[0] == 'view' and len(parts) == 3:
        view_microcode(parts[1], parts[2])
    elif parts[0] == 'edit' and len(parts) == 5:
        edit_microcode(parts[1], parts[2], int(parts[3]), parts[4])
    elif parts[0] == 'delete' and len(parts) == 4:
        delete_microcode(parts[1], parts[2], int(parts[3]))
    elif parts[0] == 'save':
        save_all()
    elif parts[0] in {'quit', 'exit'}:
        if dict_changed:
            save = input("Do you want to save the changes you've made? [y/n] ")
            if save.strip().lower().startswith('y'):
                save_all()
        print("Goodbye!")
        break
    elif parts[0] == 'help':
        show_help()
    elif parts[0] == 'table':
        export_control_signal_table()
    elif parts[0] in {'cls', 'clear'}:
        if platform.system() == 'Windows':
            os.system('cls')
        else:
            os.system('clear')
    elif parts[0] == 'addinstr' and len(parts) == 2:
        new_instr = parts[1].upper()
        if new_instr in microcode_dict:
            print(f"{new_instr} already exists.")
        else:
            microcode_dict[new_instr] = {'0': ['00000000'], '1': ['00000000'], '2': ['00000000'], '3': ['00000000']}
            dict_changed = True
            print(f"Added instruction {new_instr} with empty modes 0–3.")
    elif parts[0] == 'delinstr' and len(parts) == 2:
        instr = parts[1].upper()
        if instr in microcode_dict:
            confirm = input(f"Are you sure you want to delete {instr}? [y/n] ").lower()
            if confirm == 'y':
                del microcode_dict[instr]
                dict_changed = True
                print(f"{instr} deleted.")
            else:
                print("Deletion cancelled.")
        else:
            print(f"{instr} not found.")
    elif parts[0] == 'validate':
        if validate_microcode():
            print("All microcode entries are valid.")
        else:
            print("Warning: Some microcode entries are invalid! Files will still be saved.")
    elif parts[0] == 'microsteps' and len(parts) == 3:
        simulate_microcode(parts[1], parts[2])
    elif parts[0] == 'editcontrol' and len(parts) >= 5:
        instr = parts[1].upper()
        mode = parts[2]
        index = int(parts[3])
        control_input = parts[4:]
    
        # Ensure instruction and mode exist
        if instr not in microcode_dict or mode not in microcode_dict[instr]:
            print(f"Instruction '{instr}' or mode '{mode}' not found.")
            continue

        # Convert signal names to bit pattern
        binary = ['0'] * 32
        unmatched = []
        # Create a case-insensitive mapping from lowercase names to actual control signals
        signal_map = {sig.lower(): sig for sig in control_signals}

        for signal in control_input:
            key = signal.lower()
            if key not in signal_map:
                unmatched.append(signal)
            else:
                pos = control_signals.index(signal_map[key])
                binary[pos] = '1'

        if unmatched:
            print(f"Unrecognized control signals: {', '.join(unmatched)}")
            continue

        hex_value = f"{int(''.join(binary), 2):08X}"

        # Update the microcode
        while len(microcode_dict[instr][mode]) <= index:
            microcode_dict[instr][mode].append("00000000")

        microcode_dict[instr][mode][index] = hex_value
        dict_changed = True
        print(f"Updated {instr} mode {mode} step {index} to {hex_value} from control signals.")
    
    elif parts[0] == 'inspect' and len(parts) == 2:
        inspect_hex_value(parts[1])
    else:
        print("Invalid command - enter 'help' to see the commands list.")

