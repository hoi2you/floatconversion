
# Convert a list of '8.8 hex' numbers to 'floats'

h_nums = ['0000','0010','0020','0030','0040','004f','005e','006d',
          '007b','0089','0096','00a3','00af','00ba','00c5','00cf',
          '00d8','00e0','00e8','00ee','00f4','00f9','00fc','0100',
          '0102','0102']

f_nums = []

for num in h_nums:
      n_hex = int(num, base=16)

      i_part = n_hex >> 8
      if i_part >= 0x80:
         i_part -= 2**8
         
      d_part = n_hex & 0x00ff

      n_float = i_part + d_part/256

      f_nums.append(n_float)

print(f_nums)

