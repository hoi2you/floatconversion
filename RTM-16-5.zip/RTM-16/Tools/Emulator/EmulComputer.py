
'''
This class keeps track of the current state of the
computer & deals with executing the program instructions.

The computer's memory is divided as:
   ROM: 0x0000 - 0x7fff
   RAM: 0x8000 - 0xffef
   I/O: 0xfff0 - 0xffff

'''

from EmulFPU import FPU

class Computer():
   # Memory
   MEM_SIZE = 0xffff + 1

   # RAM address extents
   ROM_START = 0x0000
   RAM_START = 0x8000
   IO_START  = 0xfff0

   # I/O Addresses
   KBD   = 0xfff0
   SPR_1 = 0xfff1
   SPR_2 = 0xfff2
   TTY   = 0xfff3
   GR_2  = 0xfff4
   GR_1  = 0xfff5

   # Trap Address
   TRAP_ADDR = 0xcfff

   # Registers: R0 - R5, FP, IND, SP
   NUM_REGS = 9
   FP  = 0x06
   IND = 0x07
   SP  = 0x08

   # Flags
   NUM_FLAGS = 5
   C = 0
   A = 1
   E = 2
   Z = 3
   N = 4

   # Masks/Shifts
   OPCODE_MASK = 0xff00
   REGA_MASK   = 0x00f0
   REGB_MASK   = 0x000f
   COND_MASK   = 0x00f0
   FCOMP_MASK  = 0x9000
   REGA_SHIFT  = 4
   COND_SHIFT  = 4

   # Conditional Jumps
   JC   = 1
   JAGT = 2
   JCA  = 3
   JE   = 4
   JCE  = 5
   JAGE = 6
   JALE = 7
   JZ   = 8
   JMIN = 9
   JEZ  = 10
   JNE  = 11
   JPOS = 12
   JNC  = 13
   JNZ  = 14
   JALT = 15

   # Computer execution states
   ST_READY   = 0
   ST_RUNNING = 1
   ST_HALT    = 2 
   ST_END     = 3

   # Command Opcodes
   CMD_DATA_N_REG        = 0x01
   CMD_DATA_N_MEM        = 0x02
   CMD_CMP_N_MEM         = 0x03
   CMD_LOAD_MEM_REG      = 0x04
   CMD_LOAD_IDX_REG      = 0x05
   CMD_LOAD_IND_REG      = 0x06
   CMD_LOAD_REG_REG      = 0x07
   CMD_STORE_MEM_REG     = 0x08
   CMD_STORE_IDX_REG     = 0x09
   CMD_STORE_IND_REG     = 0x0a
   CMD_STORE_REG_REG     = 0x0b
   CMD_JMP_ADDR          = 0x0c
   CMD_JMP_IND_MEM       = 0x0d
   CMD_JMP_IND_REG       = 0x0e
   CMD_JMP_REG           = 0x0f
   CMD_JSR_MEM           = 0x10
   CMD_JSR_IDX           = 0x11
   CMD_JSR_REG           = 0x13
   CMD_PUSH_N            = 0x14
   CMD_PUSH_REG          = 0x15
   CMD_PUSH_IND_MEM      = 0x16
   CMD_POP_MEM           = 0x18
   CMD_POP_REG           = 0x19
   CMD_POP_IND_REG       = 0x1a
   CMD_MOVE_MEM_MEM      = 0x1c
   CMD_MOVE_REG_REG      = 0x1d
   CMD_EXGR              = 0x20
   CMD_SUB_N_MEM         = 0x21
   CMD_SUB_IND_POST_REG  = 0x22
   CMD_ADD_N_REG_REG     = 0x24
   CMD_ADD_REG_REG       = 0x25
   CMD_ADD_MEM_REG_REG   = 0x26
   CMD_ADD_IND_POST_REG  = 0x27
   CMD_SHR_N_REG_REG     = 0x28
   CMD_SHR_REG_REG       = 0x29
   CMD_SHR_N_IND         = 0x2a
   CMD_SHL_N_REG_REG     = 0x2c
   CMD_SHL_REG_REG       = 0x2d
   CMD_SHL_N_IND         = 0x2e
   CMD_NOT_MEM           = 0x30
   CMD_NOT_REG_REG       = 0x31
   CMD_NOT_REG_IND       = 0x32
   CMD_AND_N_REG_REG     = 0x34
   CMD_AND_REG_REG       = 0x35
   CMD_AND_MEM_REG_REG   = 0x36
   CMD_AND_IND_POST_REG  = 0x37
   CMD_OR_N_REG_REG      = 0x38
   CMD_OR_REG_REG        = 0x39
   CMD_OR_MEM_REG_REG    = 0x3a
   CMD_OR_IND_POST_REG   = 0x3b
   CMD_XOR_N_REG_REG     = 0x3c
   CMD_XOR_REG_REG       = 0x3d
   CMD_XOR_MEM_REG_REG   = 0x3e
   CMD_XOR_IND_POST_REG  = 0x3f
   CMD_CMP_N_REG         = 0x40
   CMD_CMP_REG_REG       = 0x41
   CMD_CMP_MEM_REG       = 0x42
   CMD_CMP_MEM_MEM       = 0x43
   CMD_INC_REG           = 0x45
   CMD_INC_MEM           = 0x46
   CMD_DEC_REG           = 0x48
   CMD_DEC_MEM           = 0x4a
   CMD_JUMPIF_MEM        = 0x4c
   CMD_JUMPIF_REG        = 0x4d
   CMD_EXGM              = 0x50
   CMD_CLF               = 0x54
   CMD_END               = 0x58
   CMD_SUB_N_REG_REG     = 0x5c
   CMD_SUB_REG_REG       = 0x5d
   CMD_SUB_MEM_REG_REG   = 0x5e
   CMD_SUB_MEM_MEM       = 0x5f
   CMD_MULT_N_REG_REG    = 0x60
   CMD_MULT_REG_REG      = 0x61
   CMD_MULT_MEM_REG_REG  = 0x62
   CMD_MULT_IND_POST_REG = 0x63
   CMD_DIV_N_REG_REG     = 0x64
   CMD_DIV_REG_REG       = 0x65
   CMD_RET               = 0x68
   CMD_CLR               = 0x6c
   CMD_SPLASH            = 0x70
   CMD_PIXEL             = 0x71
   CMD_STORE_REG_OFF_REG = 0x74
   CMD_LOAD_OFF_REG_REG  = 0x78
   CMD_FMULT_N_REG_REG   = 0x7c
   CMD_FMULT_REG_REG     = 0x7d
   CMD_FMULT_MEM_REG_REG = 0x7e
   CMD_FMULT_MEM_MEM     = 0x7f
   CMD_FADD_N_REG_REG    = 0x80
   CMD_FADD_REG_REG      = 0x81
   CMD_FADD_MEM_REG_REG  = 0x82
   CMD_FADD_MEM_MEM      = 0x83
   CMD_FSUB_N_REG_REG    = 0x84
   CMD_FSUB_REG_REG      = 0x85
   CMD_FSUB_MEM_REG_REG  = 0x86
   CMD_FSUB_MEM_MEM      = 0x87
   CMD_FDIV_N_REG_REG    = 0x88
   CMD_FDIV_REG_REG      = 0x89
   CMD_FDIV_MEM_REG_REG  = 0x8a
   CMD_FDIV_MEM_MEM      = 0x8b
   CMD_FSQRT_N_REG       = 0x8c
   CMD_FSQRT_REG_REG     = 0x8d
   CMD_FSQRT_MEM_REG     = 0x8e
   CMD_FSQRT_MEM_MEM     = 0x8f
   CMD_FCOMP_N_REG       = 0x90
   CMD_FCOMP_REG_REG     = 0x91
   CMD_FCOMP_MEM_REG     = 0x92
   CMD_FCOMP_MEM_MEM     = 0x93

   # The Add/Sub/Shift commands affect the Carry Flag
   CARRY_CMDS = [CMD_ADD_N_REG_REG, CMD_ADD_REG_REG, CMD_ADD_MEM_REG_REG, CMD_ADD_IND_POST_REG,
                 CMD_SUB_N_REG_REG, CMD_SUB_REG_REG, CMD_SUB_MEM_REG_REG,
                 CMD_SUB_MEM_MEM, CMD_SUB_N_MEM, CMD_SUB_IND_POST_REG,
                 CMD_SHR_N_REG_REG, CMD_SHR_REG_REG, CMD_SHR_N_IND,
                 CMD_SHL_N_REG_REG, CMD_SHL_REG_REG, CMD_SHL_N_IND]
   
   # The '#n,Rx,Ry' commands
   N_REG_REG_CMDS =[CMD_ADD_N_REG_REG, CMD_SHR_N_REG_REG, CMD_SHL_N_REG_REG,
                    CMD_AND_N_REG_REG, CMD_OR_N_REG_REG, CMD_XOR_N_REG_REG,
                    CMD_SUB_N_REG_REG, CMD_MULT_N_REG_REG, CMD_DIV_N_REG_REG]

   # The 'addr,Rx,Ry' commands
   MEM_REG_REG_CMDS = [CMD_ADD_MEM_REG_REG, CMD_AND_MEM_REG_REG, CMD_OR_MEM_REG_REG,
                       CMD_XOR_MEM_REG_REG, CMD_SUB_MEM_REG_REG, CMD_MULT_MEM_REG_REG]

   # The FCOMP commands
   FCOMP_CMDS = [CMD_FCOMP_N_REG, CMD_FCOMP_REG_REG, CMD_FCOMP_MEM_REG, CMD_FCOMP_MEM_MEM]

   # Signed Integer Limits
   INT_HIGH = 2**15 - 1
   INT_LOW = -(2**15)

   # Reset everything on initialisation
   def __init__(self):
      self.mem = [0x0000] * Computer.MEM_SIZE     # The memory
      self.gr_mem = [0x0000] * Computer.MEM_SIZE  # The graphics memory (Initialise with black)
      self.regs = [0x0000] * Computer.NUM_REGS    # Registers R0 - R5, FP, IND, SP
      self.flags = [False] * Computer.NUM_FLAGS   # The C, A, E, Z, N flags
      self.iar = 0x0000                           # Instruction address register
      self.cmd = 0x00                             # The current instruction type
      self.instr = 0x0000                         # The current instruction
      self.cond = 0x0000                          # The conditional jump
      self.two_byte_instr = False                 # Is it a 2 byte instruction
      self.three_byte_instr = False               # Is it a 3 byte instruction
      self.rega = 0                               # The A register
      self.regb = 0                               # The B register
      self.byte_2 = 0x0000                        # Used for the 2nd byte of 2 or 3 byte instructions
      self.byte_3 = 0x0000                        # Used for the 3rd byte of 3 byte instructions
      self.asm_code = ''                          # Used when displaying the instruction
      self.state = Computer.ST_READY              # The computer's current execution state
      self.breakpoints = []                       # List of current breakpoints
      self.InitialRAM = None                      # Store RAM machine code for reloading at resets
      self.fpu = FPU()                            # Floating Point Unit

   # Return the string representation of a register
   def strReg(reg):
      if reg <= 5:
         return f'R{reg}'
      elif reg == Computer.FP:
         return 'FP'
      elif reg == Computer.IND:
         return 'IND'
      elif reg == Computer.SP:
         return 'SP'
      else:
         return 'Invalid Register'

   # Get valid hex or decimal user input
   def GetInput(self, text, hex=True, char=False):
      valid = False
      while not valid:
         try:
            if hex:
               val = int(input(text),16) & 0xffff
            elif not char:
               val = int(input(text))
            else:
               val = input(text)
               if len(val) == 0:
                  return 0x0a  # Return LF
               if len(val) != 1:
                  raise ValueError
               else:
                  val = ord(val)
            valid = True
         except ValueError:
            print('Invalid Value ...')
            valid = False
         except:
            exit()
      return val

   # The following set/report the current execution state
   def Run(self):
      self.state = Computer.ST_RUNNING

   def Ready(self):
      return self.state == Computer.ST_READY

   def Running(self):
      return self.state == Computer.ST_RUNNING

   def Halted(self):
      return self.state == Computer.ST_HALT

   def Stopped(self):
      return self.state == Computer.ST_END

   # Get code into memory
   def LoadMemory(self, fileIn, RAM=False):
      if RAM:
         addr = Computer.RAM_START
         if self.InitialRAM == None:
            self.InitialRAM = fileIn
      else:
         addr = Computer.ROM_START

      with open(fileIn,'r') as mc:
         for line in mc:
            line = line.strip()

            # Ignore header line
            if line.startswith('v3.0 hex words plain'):
                  continue

            codes = line.split(' ')
            for code in codes:
               if code == '':
                  continue

               if RAM and addr >= Computer.MEM_SIZE:
                  print("\n*** CRASH ***\nProgram too big for RAM\n")
                  exit()
               elif not RAM and addr >= Computer.RAM_START:
                  print("\n*** CRASH ***\nProgram too big for ROM\n")
                  exit()

               self.mem[addr] = int(code, 16)
               addr += 1

   # Reset everything bar the ROM
   def Reset(self):
      for i in range(Computer.RAM_START, Computer.MEM_SIZE):
         self.mem[i] = 0
      Computer.LoadMemory(self, self.InitialRAM, RAM=True)
      for i in range(Computer.NUM_REGS):
         self.regs[i] = 0
      for i in range(Computer.NUM_FLAGS):
         self.flags[i] = False
      self.iar = 0x0000
      self.state = Computer.ST_READY

   # Show the next instruction to be executed & the contents of registers/flags
   def DisplayState(self):
      if self.state == Computer.ST_READY:
         print('Waiting to run - Perform Run (R) or Step (S) to start\n')
         return

      print(f'R0: 0x{self.regs[0]:04x}, R1:  0x{self.regs[1]:04x}, R2: 0x{self.regs[2]:04x}, R3: 0x{self.regs[3]:04x}, R4:  0x{self.regs[4]:04x}')
      print(f'R5: 0x{self.regs[5]:04x}, IND: 0x{self.regs[Computer.IND]:04x}, SP: 0x{self.regs[Computer.SP]:04x}, ', end='')

      if self.regs[Computer.FP] is None:
         print(f'FP:   ??    ', end='')
      else:
         print(f'FP: 0x{self.regs[Computer.FP]:04x}, ', end='')

      if self.two_byte_instr:
         print(f'IAR: 0x{self.iar-1:04x}')
      elif self.three_byte_instr:
         print(f'IAR: 0x{self.iar-2:04x}')
      else:
         print(f'IAR: 0x{self.iar:04x}')

      print(f'\nFlags - N: {self.flags[Computer.N]}, C: {self.flags[Computer.C]}, A: {self.flags[Computer.A]}, E: {self.flags[Computer.E]}, Z: {self.flags[Computer.Z]}')
      nan, pos_inf, neg_inf, z = self.fpu.get_flags()
      print(f'FPU - NaN: {nan}, +INF: {pos_inf}, -INF: {neg_inf}, Z: {z}\n')

      if self.state == Computer.ST_END:
         print(f'Program has completed - Perform Reset (RS) to re-run.\n')
      else:
         print(f'Next Instr: {self.asm_code} (0x{self.instr:04x}', end='')
         if self.two_byte_instr:
            print(f', 0x{self.byte_2:04x})\n')
         elif self.three_byte_instr:
            print(f', 0x{self.byte_2:04x}, 0x{self.byte_3:04x})\n')
         else:
            print(f')\n')

   # Show the current breakpoints
   def DisplayBreakpoints(self):
      if len(self.breakpoints) == 0:
         print('There are no breakpoints set\n')
         return

      print(f'Current breakpoints: ', end='')
      for bp in self.breakpoints:
         print(f'0x{bp:04x} ', end='')
      print('\n')

   # Add a breakpoint
   def SetBreakpoint(self):
      bp = Computer.GetInput(self, 'Add a breakpoint at PC = 0x')
      if bp not in self.breakpoints:
         self.breakpoints.append(bp)
      print()

   # Delete a breakpoint
   def DeleteBreakpoint(self):
      bp = Computer.GetInput(self, 'Remove breakpoint at PC = 0x')
      if bp in self.breakpoints:
         self.breakpoints.remove(bp)
         print()
      else:
         print("\nBreakpoint doesn't exist\n")

   # Display a memory region/location
   def DisplayMemory(self):
      addr = Computer.GetInput(self, 'Starting Address: 0x')
      num_words = Computer.GetInput(self, 'How many words: ', hex=False)

      if num_words == 0:
         print()

      # A single address has been requested
      elif num_words == 1:
         val = self.mem[addr]
         print(f'\nMemory 0x{addr:04x}: {val:04x}\n')

      # # A range of addresses has been requested
      elif num_words > 1:
         for i in range(num_words):
            if i % 16 == 0:
               print(f'\nMemory 0x{addr+i:04x}:', end='')
            elif i % 8 == 0:
               print(' ', end='')
            print(f' {self.mem[addr+i]:04x}', end='')
         print('\n')

   # Set a single memory location
   def SetMemory(self):
      addr = Computer.GetInput(self, 'Address: 0x')
      val = Computer.GetInput(self, 'Val: 0x')
      self.mem[addr] = val
      print()

   # Dump the graphics memory
   def GraphicsDump(self):
      with open('Graphics.dat','w') as mc:
         mc.write('v3.0 hex words plain\n')
         for addr in range(Computer.MEM_SIZE):
            count = addr + 1
            word = hex(self.gr_mem[addr])[2:]
            if (count % 16) == 0:
               sep = '\n'
            elif (count % 8) == 0:
               sep = '  '
            else:
               sep = ' '
            while len(word) < 4:
               word = '0' + word
            mc.write(word + sep)
      print("Graphics dumped to 'Graphics.dat'\n")

   # Set the C, A, E, Z & N flags
   # NB: The A & E flags may not agree with RTM-16 for the single argument 
   #     commands INC/DEC/NOT/CLR as RTM-16 doesn't use the 'B' data in those
   #     cases - So the A & E flags are meaningless for those commands.
   def SetFlags(self, res):
      if self.cmd in [Computer.CMD_CMP_N_MEM, Computer.CMD_SUB_N_MEM]:
         a = self.byte_2
         b = self.mem[self.byte_3]
      elif self.cmd in [Computer.CMD_CMP_MEM_MEM, Computer.CMD_FCOMP_MEM_MEM, Computer.CMD_SUB_MEM_MEM]:
         a = self.mem[self.byte_2]
         b = self.mem[self.byte_3]
      elif self.cmd in [Computer.CMD_CMP_N_REG, Computer.CMD_FCOMP_N_REG]:
         a = self.byte_2
         b = self.regs[self.regb]
      elif self.cmd in [Computer.CMD_CMP_MEM_REG, Computer.CMD_FCOMP_MEM_REG]:
         a = self.mem[self.byte_2]
         b = self.regs[self.regb]
      elif self.cmd in Computer.N_REG_REG_CMDS:
         a = self.byte_2
         b = self.regs[self.rega]
      elif self.cmd in Computer.MEM_REG_REG_CMDS:
         a = self.mem[self.byte_2]
         b = self.regs[self.rega]
      elif self.cmd in [Computer.CMD_SHR_N_IND, Computer.CMD_SHL_N_IND]:
         a = self.byte_2
         b = self.mem[self.regs[self.regb]]   
      else:
         a = self.regs[self.rega]
         b = self.regs[self.regb]

      # Carry Flag
      self.flags[Computer.C] = False
      if self.cmd in Computer.CARRY_CMDS and res > 0xffff:
         self.flags[Computer.C] = True

      # Greater Than Flag
      self.flags[Computer.A] = False
      a_neg = False
      if (a & 0x8000) == 0x8000:
         a_neg = True
      b_neg = False
      if (b & 0x8000) == 0x8000:
         b_neg = True

      if a_neg and b_neg:
         if self.cmd in Computer.FCOMP_CMDS:
            if a < b:
               self.flags[Computer.A] = True
         elif a > b:
            self.flags[Computer.A] = True
      elif a_neg and not b_neg:
         self.flags[Computer.A] = False
      elif not a_neg and b_neg:
         self.flags[Computer.A] = True
      elif a > b:
         self.flags[Computer.A] = True

      # Equals Flag
      self.flags[Computer.E] = False
      if a == b:
         self.flags[Computer.E] = True

      # Zero Flag
      self.flags[Computer.Z] = False
      if res & 0xffff == 0:
         self.flags[Computer.Z] = True

      # Negative Flag
      self.flags[Computer.N] = False
      if res & 0x8000 == 0x8000:
         self.flags[Computer.N] = True

   # Fetch the next instruction to be computed
   def FetchInstr(self):
      self.two_byte_instr = False
      self.three_byte_instr = False

      # Is the instruction at a breakpoint ?
      if self.iar in self.breakpoints:
         self.state = Computer.ST_HALT
         print(f'Hit breakpoint at PC = 0x{self.iar:04x}\n')

      # The instruction is pointed to by the PC
      self.instr = self.mem[self.iar]

      # Now prepare for function execution:
      #   Get source/destination registers
      #   Set the 'Display State' info
      #   Get the 2nd byte for 2 or 3 byte commands
      #   Get the 3rd byte for 3 byte commands

      # DATA #n,Rx / DATA addrn,Rx
      if self.instr & Computer.OPCODE_MASK == 0x0100:
         self.cmd = Computer.CMD_DATA_N_REG
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'DATA #0x{self.byte_2:04x},{Computer.strReg(self.regb)}'

      # DATA #n,addr / DATA addrn,addr
      elif self.instr & Computer.OPCODE_MASK == 0x0200:
         self.cmd = Computer.CMD_DATA_N_MEM
         self.three_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.iar += 1
         self.byte_3 = self.mem[self.iar]
         self.asm_code = f'DATA #0x{self.byte_2:04x},0x{self.byte_3:04x}'

      # CMP #n,addr
      elif self.instr & Computer.OPCODE_MASK == 0x0300:
         self.cmd = Computer.CMD_CMP_N_MEM
         self.three_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.iar += 1
         self.byte_3 = self.mem[self.iar]
         self.asm_code = f'CMP #0x{self.byte_2:04x},0x{self.byte_3:04x}'

      # LOAD addr,Rx
      elif self.instr & Computer.OPCODE_MASK == 0x0400:
         self.cmd = Computer.CMD_LOAD_MEM_REG
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'LOAD 0x{self.byte_2:04x},{Computer.strReg(self.regb)}'

      # LOAD Rx+IND,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x0500:
         self.cmd = Computer.CMD_LOAD_IDX_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'LOAD {Computer.strReg(self.rega)}+IND,{Computer.strReg(self.regb)}'


      # LOAD [addr],Rx
      elif self.instr & Computer.OPCODE_MASK == 0x0600:
         self.cmd = Computer.CMD_LOAD_IND_REG
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'LOAD [0x{self.byte_2:04x}],{Computer.strReg(self.regb)}'

      # LOAD Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x0700:
         self.cmd = Computer.CMD_LOAD_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'LOAD {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'
      
      # STORE Rx,addr
      elif self.instr & Computer.OPCODE_MASK == 0x0800:
         self.cmd = Computer.CMD_STORE_MEM_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'STORE {Computer.strReg(self.rega)},0x{self.byte_2:04x}'
      
      # STORE Rx,Ry+IND
      elif self.instr & Computer.OPCODE_MASK == 0x0900:
         self.cmd = Computer.CMD_STORE_IDX_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'LOAD {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}+IND'

      # STORE Rx,[addr]
      elif self.instr & Computer.OPCODE_MASK == 0x0a00:
         self.cmd = Computer.CMD_STORE_IND_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'STORE {Computer.strReg(self.rega)},[0x{self.byte_2:04x}]'

      # STORE Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x0b00:
         self.cmd = Computer.CMD_STORE_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'STORE {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # JMP addr
      elif self.instr & Computer.OPCODE_MASK == 0x0c00:
         self.cmd = Computer.CMD_JMP_ADDR
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'JMP 0x{self.byte_2:04x}'

      # JMP (addr)
      elif self.instr & Computer.OPCODE_MASK == 0x0d00:
         self.cmd = Computer.CMD_JMP_IND_MEM
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'JMP (0x{self.byte_2:04x})'

      # JMP [Rx]
      elif self.instr & Computer.OPCODE_MASK == 0x0e00:
         self.cmd = Computer.CMD_JMP_IND_REG
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'JMP [{Computer.strReg(self.regb)}]'

      # JMP Rx
      elif self.instr & Computer.OPCODE_MASK == 0x0f00:
         self.cmd = Computer.CMD_JMP_REG
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'JMP {Computer.strReg(self.regb)}'

      # JSR addr
      elif self.instr & Computer.OPCODE_MASK == 0x1000:
         self.cmd = Computer.CMD_JSR_MEM
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'JSR 0x{self.byte_2:04x}'

      # JSR Rx+IND
      elif self.instr & Computer.OPCODE_MASK == 0x1100:
         self.cmd = Computer.CMD_JSR_IDX
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'JSR {Computer.strReg(self.regb)}+IND'

      # JSR Rx
      elif self.instr & Computer.OPCODE_MASK == 0x1300:
         self.cmd = Computer.CMD_JSR_REG
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'JSR {Computer.strReg(self.regb)}'

      # PUSH #n / PUSH addrn
      elif self.instr & Computer.OPCODE_MASK == 0x1400:
         self.cmd = Computer.CMD_PUSH_N
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'PUSH 0x{self.byte_2:04x}'

      # PUSH Rx
      elif self.instr & Computer.OPCODE_MASK == 0x1500:
         self.cmd = Computer.CMD_PUSH_REG
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'PUSH {Computer.strReg(self.regb)}'

      # PUSH (addr)
      elif self.instr & Computer.OPCODE_MASK == 0x1600:
         self.cmd = Computer.CMD_PUSH_IND_MEM
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'PUSH (0x{self.byte_2:04x})'

      # POP addr
      elif self.instr & Computer.OPCODE_MASK == 0x1800:
         self.cmd = Computer.CMD_POP_MEM
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'POP 0x{self.byte_2:04x}'
      
      # POP Rx
      elif self.instr & Computer.OPCODE_MASK == 0x1900:
         self.cmd = Computer.CMD_POP_REG
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'POP {Computer.strReg(self.regb)}'

      # POP [Rx]
      elif self.instr & Computer.OPCODE_MASK == 0x1a00:
         self.cmd = Computer.CMD_POP_IND_REG
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'POP [{Computer.strReg(self.regb)}]'

      # MOVE addr1,addr2
      elif self.instr & Computer.OPCODE_MASK == 0x1c00:
         self.cmd = Computer.CMD_MOVE_MEM_MEM
         self.three_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.iar += 1
         self.byte_3 = self.mem[self.iar]
         self.asm_code = f'MOVE 0x{self.byte_2:04x},0x{self.byte_3:04x}'

      # MOVE Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x1d00:
         self.cmd = Computer.CMD_MOVE_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'MOVE {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # EXGR Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x2000:
         self.cmd = Computer.CMD_EXGR
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'EXGR {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # SUB #n,addr
      elif self.instr & Computer.OPCODE_MASK == 0x2100:
         self.cmd = Computer.CMD_SUB_N_MEM
         self.three_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.iar += 1
         self.byte_3 = self.mem[self.iar]
         self.asm_code = f'SUB #0x{self.byte_2:04x},0x{self.byte_3:04x}'

      # SUB [Rx]+,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x2200:
         self.cmd = Computer.CMD_SUB_IND_POST_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'SUB [{Computer.strReg(self.rega)}]+,{Computer.strReg(self.regb)}'

      # ADD #n,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x2400:
         self.cmd = Computer.CMD_ADD_N_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'ADD #0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # ADD Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x2500:
         self.cmd = Computer.CMD_ADD_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'ADD {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # ADD addr,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x2600:
         self.cmd = Computer.CMD_ADD_MEM_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'ADD 0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # ADD [Rx]+,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x2700:
         self.cmd = Computer.CMD_ADD_IND_POST_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'ADD [{Computer.strReg(self.rega)}]+,{Computer.strReg(self.regb)}'

      # SHR #n,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x2800:
         self.cmd = Computer.CMD_SHR_N_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'SHR #0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # SHR Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x2900:
         self.cmd = Computer.CMD_SHR_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'SHR {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # SHR #n,(Rx)
      elif self.instr & Computer.OPCODE_MASK == 0x2a00:
         self.cmd = Computer.CMD_SHR_N_IND
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'SHR 0x{self.byte_2:04x},{Computer.strReg(self.regb)}'

      # SHL #n,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x2c00:
         self.cmd = Computer.CMD_SHL_N_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'SHL #0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # SHL Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x2d00:
         self.cmd = Computer.CMD_SHL_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'SHL {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # SHL #n,(Rx)
      elif self.instr & Computer.OPCODE_MASK == 0x2e00:
         self.cmd = Computer.CMD_SHL_N_IND
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'SHL 0x{self.byte_2:04x},{Computer.strReg(self.regb)}'

      # NOT addr
      elif self.instr & Computer.OPCODE_MASK == 0x3000:
         self.cmd = Computer.CMD_NOT_MEM
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'NOT 0x{self.byte_2:04x}'

      # NOT Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x3100:
         self.cmd = Computer.CMD_NOT_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'NOT {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # NOT Rx,(Ry)
      elif self.instr & Computer.OPCODE_MASK == 0x3200:
         self.cmd = Computer.CMD_NOT_REG_IND
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'NOT {Computer.strReg(self.rega)},({Computer.strReg(self.regb)})'

      # AND #n,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x3400:
         self.cmd = Computer.CMD_AND_N_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'AND #0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # AND Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x3500:
         self.cmd = Computer.CMD_AND_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'AND {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # AND addr,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x3600:
         self.cmd = Computer.CMD_AND_MEM_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'AND 0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # AND [Rx]+,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x3700:
         self.cmd = Computer.CMD_AND_IND_POST_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'AND [{Computer.strReg(self.rega)}]+,{Computer.strReg(self.regb)}'

      # OR #n,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x3800:
         self.cmd = Computer.CMD_OR_N_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'OR #0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # OR Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x3900:
         self.cmd = Computer.CMD_OR_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'OR {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # OR addr,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x3a00:
         self.cmd = Computer.CMD_OR_MEM_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'OR 0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # OR [Rx]+,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x3b00:
         self.cmd = Computer.CMD_OR_IND_POST_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'OR [{Computer.strReg(self.rega)}]+,{Computer.strReg(self.regb)}'

      # XOR #n,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x3c00:
         self.cmd = Computer.CMD_XOR_N_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'XOR #0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # XOR Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x3d00:
         self.cmd = Computer.CMD_XOR_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'XOR {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # XOR addr,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x3e00:
         self.cmd = Computer.CMD_XOR_MEM_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'XOR 0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # XOR [Rx]+,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x3f00:
         self.cmd = Computer.CMD_XOR_IND_POST_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'XOR [{Computer.strReg(self.rega)}]+,{Computer.strReg(self.regb)}'

      # CMP #n,Rx / FCOMP #n,Rx
      elif (self.instr & Computer.OPCODE_MASK == 0x4000) or (self.instr & Computer.OPCODE_MASK == 0x9000):
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         if self.instr & Computer.FCOMP_MASK:
            self.cmd = Computer.CMD_FCOMP_N_REG
            self.asm_code = f'FCOMP #0x{self.byte_2:04x},{Computer.strReg(self.regb)}'
         else:
            self.cmd = Computer.CMD_CMP_N_REG
            self.asm_code = f'CMP #0x{self.byte_2:04x},{Computer.strReg(self.regb)}'

      # CMP Rx,Ry / FCOMP Rx,Ry
      elif (self.instr & Computer.OPCODE_MASK == 0x4100) or (self.instr & Computer.OPCODE_MASK == 0x9100):
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         if self.instr & Computer.FCOMP_MASK:
            self.cmd = Computer.CMD_FCOMP_REG_REG
            self.asm_code = f'FCOMP {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'
         else:
            self.cmd = Computer.CMD_CMP_REG_REG
            self.asm_code = f'CMP {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # CMP addr,Rx / FCOMP addr,Rx
      elif (self.instr & Computer.OPCODE_MASK == 0x4200) or (self.instr & Computer.OPCODE_MASK == 0x9200):
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         if self.instr & Computer.FCOMP_MASK:
            self.cmd = Computer.CMD_FCOMP_MEM_REG
            self.asm_code = f'FCOMP 0x{self.byte_2:04x},{Computer.strReg(self.regb)}'
         else:
            self.cmd = Computer.CMD_CMP_MEM_REG
            self.asm_code = f'CMP 0x{self.byte_2:04x},{Computer.strReg(self.regb)}'

      # CMP addr1,addr2 / FCOMP addr1,addr2
      elif self.instr & Computer.OPCODE_MASK == 0x4300:
         self.three_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.iar += 1
         self.byte_3 = self.mem[self.iar]
         if self.instr & Computer.FCOMP_MASK:
            self.cmd = Computer.CMD_FCOMP_MEM_MEM
            self.asm_code = f'FCOMP 0x{self.byte_2:04x},0x{self.byte_3:04x}'
         else:
            self.cmd = Computer.CMD_CMP_MEM_MEM
            self.asm_code = f'CMP 0x{self.byte_2:04x},0x{self.byte_3:04x}'

      # INC Rx
      elif self.instr & Computer.OPCODE_MASK == 0x4500:
         self.cmd = Computer.CMD_INC_REG
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'INC {Computer.strReg(self.regb)}'

      # INC addr
      elif self.instr & Computer.OPCODE_MASK == 0x4600:
         self.cmd = Computer.CMD_INC_MEM
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'INC 0x{self.byte_2:04x}'

      # DEC Rx
      elif self.instr & Computer.OPCODE_MASK == 0x4800:
         self.cmd = Computer.CMD_DEC_REG
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'DEC {Computer.strReg(self.regb)}'

      # DEC addr
      elif self.instr & Computer.OPCODE_MASK == 0x4a00:
         self.cmd = Computer.CMD_DEC_MEM
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'DEC 0x{self.byte_2:04x}'

      # JUMPIF addr / # JUMPIF Rx
      elif self.instr & Computer.OPCODE_MASK == 0x4c00 or \
           self.instr & Computer.OPCODE_MASK == 0x4d00:
         self.cond = (self.instr & Computer.COND_MASK) >> Computer.COND_SHIFT
         if self.cond == Computer.JC:
             str_cond = 'JC'
         elif self.cond == Computer.JAGT:
             str_cond = 'JAGT'
         elif self.cond == Computer.JCA:
             str_cond = 'JCA'
         elif self.cond == Computer.JE:
             str_cond = 'JE'
         elif self.cond == Computer.JCE:
             str_cond = 'JCE'
         elif self.cond == Computer.JAGE:
             str_cond = 'JAGE'
         elif self.cond == Computer.JALE:
             str_cond = 'JALE'
         elif self.cond == Computer.JZ:
             str_cond = 'JZ'
         elif self.cond == Computer.JMIN:
             str_cond = 'JMIN'
         elif self.cond == Computer.JEZ:
             str_cond = 'JEZ'
         elif self.cond == Computer.JNE:
             str_cond = 'JNE'
         elif self.cond == Computer.JPOS:
             str_cond = 'JPOS'
         elif self.cond == Computer.JNC:
             str_cond = 'JNC'
         elif self.cond == Computer.JNZ:
             str_cond = 'JNZ'
         elif self.cond == Computer.JALT:
             str_cond = 'JALT'

         if self.instr & Computer.OPCODE_MASK == 0x4c00:
            self.cmd = Computer.CMD_JUMPIF_MEM
            self.two_byte_instr = True
            self.iar += 1
            self.byte_2 = self.mem[self.iar]
            self.asm_code = f'{str_cond} 0x{self.byte_2:04x}'
         else:
            self.cmd = Computer.CMD_JUMPIF_REG
            self.regb = self.instr & Computer.REGB_MASK
            self.asm_code = f'{str_cond} {Computer.strReg(self.regb)}'

      # EXGM addr1,addr2
      elif self.instr & Computer.OPCODE_MASK == 0x5000:
         self.cmd = Computer.CMD_EXGM
         self.three_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.iar += 1
         self.byte_3 = self.mem[self.iar]
         self.asm_code = f'EXGM 0x{self.byte_2:04x},0x{self.byte_3:04x}'

      # CLF
      elif self.instr & Computer.OPCODE_MASK == 0x5400:
         self.cmd = Computer.CMD_CLF
         self.asm_code = f'CLF'

      # END
      elif self.instr & Computer.OPCODE_MASK == 0x5800:
         self.cmd = Computer.CMD_END
         self.asm_code = f'END'

      # SUB #n,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x5c00:
         self.cmd = Computer.CMD_SUB_N_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'SUB #0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # SUB Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x5d00:
         self.cmd = Computer.CMD_SUB_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'SUB {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # SUB addr,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x5e00:
         self.cmd = Computer.CMD_SUB_MEM_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'SUB 0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # SUB addr1,addr2
      elif self.instr & Computer.OPCODE_MASK == 0x5f00:
         self.cmd = Computer.CMD_SUB_MEM_MEM
         self.three_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.iar += 1
         self.byte_3 = self.mem[self.iar]
         self.asm_code = f'SUB 0x{self.byte_2:04x},0x{self.byte_3:04x}'

      # MULT #n,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x6000:
         self.cmd = Computer.CMD_MULT_N_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'MULT #0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # MULT Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x6100:
         self.cmd = Computer.CMD_MULT_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'MULT {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # MULT addr,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x6200:
         self.cmd = Computer.CMD_MULT_MEM_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'MULT 0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # MULT [Rx]+,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x6300:
         self.cmd = Computer.CMD_MULT_IND_POST_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'MULT [{Computer.strReg(self.rega)}]+,{Computer.strReg(self.regb)}'

      # DIV #n,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x6400:
         self.cmd = Computer.CMD_DIV_N_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'DIV #0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # DIV Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x6500:
         self.cmd = Computer.CMD_DIV_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'DIV {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # RET
      elif self.instr & Computer.OPCODE_MASK == 0x6800:
         self.cmd = Computer.CMD_RET
         self.asm_code = 'RET'

      # CLR Rx
      elif self.instr & Computer.OPCODE_MASK == 0x6c00:
         self.cmd = Computer.CMD_CLR
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'CLR {Computer.strReg(self.regb)}'

      # SPLASH addr
      elif self.instr & Computer.OPCODE_MASK == 0x7000:
         self.cmd = Computer.CMD_SPLASH
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'SPLASH 0x{self.byte_2:04x}'

      # PIXEL addr,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x7100:
         self.cmd = Computer.CMD_PIXEL
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'PIXEL 0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # STORE Rx,n+Ry
      elif self.instr & Computer.OPCODE_MASK == 0x7400:
         self.cmd = Computer.CMD_STORE_REG_OFF_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'STORE {Computer.strReg(self.rega)},0x{self.byte_2:04x}+{Computer.strReg(self.regb)}'
      
      # LOAD n+Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x7800:
         self.cmd = Computer.CMD_LOAD_OFF_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'LOAD 0x{self.byte_2:04x}+{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # FMULT #n,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x7c00:
         self.cmd = Computer.CMD_FMULT_N_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'FMULT #0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # FMULT Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x7d00:
         self.cmd = Computer.CMD_FMULT_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'FMULT {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # FMULT addr,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x7e00:
         self.cmd = Computer.CMD_FMULT_MEM_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'FMULT 0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # FMULT addr1,addr2
      elif self.instr & Computer.OPCODE_MASK == 0x7f00:
         self.cmd = Computer.CMD_FMULT_MEM_MEM
         self.three_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.iar += 1
         self.byte_3 = self.mem[self.iar]
         self.asm_code = f'FMULT 0x{self.byte_2:04x},0x{self.byte_3:04x}'

      # FADD #n,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x8000:
         self.cmd = Computer.CMD_FADD_N_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'FADD #0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # FADD Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x8100:
         self.cmd = Computer.CMD_FADD_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'FADD {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # FADD addr,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x8200:
         self.cmd = Computer.CMD_FADD_MEM_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'FADD 0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # FADD addr1,addr2
      elif self.instr & Computer.OPCODE_MASK == 0x8300:
         self.cmd = Computer.CMD_FADD_MEM_MEM
         self.three_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.iar += 1
         self.byte_3 = self.mem[self.iar]
         self.asm_code = f'FADD 0x{self.byte_2:04x},0x{self.byte_3:04x}'

      # FSUB #n,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x8400:
         self.cmd = Computer.CMD_FSUB_N_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'FSUB #0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # FSUB Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x8500:
         self.cmd = Computer.CMD_FSUB_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'FSUB {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # FSUB addr,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x8600:
         self.cmd = Computer.CMD_FSUB_MEM_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'FSUB 0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # FSUB addr1,addr2
      elif self.instr & Computer.OPCODE_MASK == 0x8700:
         self.cmd = Computer.CMD_FSUB_MEM_MEM
         self.three_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.iar += 1
         self.byte_3 = self.mem[self.iar]
         self.asm_code = f'FSUB 0x{self.byte_2:04x},0x{self.byte_3:04x}'

      # FDIV #n,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x8800:
         self.cmd = Computer.CMD_FDIV_N_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'FDIV #0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # FDIV Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x8900:
         self.cmd = Computer.CMD_FDIV_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'FDIV {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # FDIV addr,Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x8a00:
         self.cmd = Computer.CMD_FDIV_MEM_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'FDIV 0x{self.byte_2:04x},{Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # FDIV addr1,addr2
      elif self.instr & Computer.OPCODE_MASK == 0x8b00:
         self.cmd = Computer.CMD_FDIV_MEM_MEM
         self.three_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.iar += 1
         self.byte_3 = self.mem[self.iar]
         self.asm_code = f'FDIV 0x{self.byte_2:04x},0x{self.byte_3:04x}'

      # FSQRT #n,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x8c00:
         self.cmd = Computer.CMD_FSQRT_N_REG
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'FSQRT #0x{self.byte_2:04x},{Computer.strReg(self.regb)}'

      # FSQRT Rx,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x8d00:
         self.cmd = Computer.CMD_FSQRT_REG_REG
         self.rega = (self.instr & Computer.REGA_MASK) >> Computer.REGA_SHIFT
         self.regb = self.instr & Computer.REGB_MASK
         self.asm_code = f'FSQRT {Computer.strReg(self.rega)},{Computer.strReg(self.regb)}'

      # FSQRT addr,Ry
      elif self.instr & Computer.OPCODE_MASK == 0x8e00:
         self.cmd = Computer.CMD_FSQRT_MEM_REG
         self.regb = self.instr & Computer.REGB_MASK
         self.two_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.asm_code = f'FSQRT 0x{self.byte_2:04x},{Computer.strReg(self.regb)}'

      # FSQRT addr1,addr2
      elif self.instr & Computer.OPCODE_MASK == 0x8f00:
         self.cmd = Computer.CMD_FSQRT_MEM_MEM
         self.three_byte_instr = True
         self.iar += 1
         self.byte_2 = self.mem[self.iar]
         self.iar += 1
         self.byte_3 = self.mem[self.iar]
         self.asm_code = f'FSQRT 0x{self.byte_2:04x},0x{self.byte_3:04x}'

   # Execute the current instruction:
   #   Perform the required calculation
   #   Update the flags
   #   Adjust the PC

   def ExecInstr(self):
      # DATA #n,Rx
      if self.cmd == Computer.CMD_DATA_N_REG:
         self.regs[self.regb] = self.mem[self.iar]
         self.iar += 1

      # DATA #n,addr
      elif self.cmd == Computer.CMD_DATA_N_MEM:
         self.regs[Computer.FP] = None
         self.mem[self.byte_3] = self.byte_2
         if self.byte_3 == Computer.TRAP_ADDR:
            print('*************************')
            print(f'Trap Code 0x{self.byte_2:04x} Detected')
            print('*************************\n')
         self.iar += 1

      # CMP #n,addr
      elif self.cmd == Computer.CMD_CMP_N_MEM:
         res = 0x0001
         Computer.SetFlags(self, res)
         self.iar += 1

      # LOAD addr,Rx
      elif self.cmd == Computer.CMD_LOAD_MEM_REG:
         if self.byte_2 == Computer.KBD:
            self.mem[Computer.KBD] = Computer.GetInput(self, 'Enter KBD Char: ', hex=False, char=True)
            print()
         self.regs[self.regb] = self.mem[self.byte_2]
         self.iar += 1

      # LOAD Rx+IND,Ry
      elif self.cmd == Computer.CMD_LOAD_IDX_REG:
         addr = self.regs[self.rega] + self.regs[self.IND]
         if addr == Computer.KBD:
            self.mem[Computer.KBD] = Computer.GetInput(self, 'Enter KBD Char: ', hex=False, char=True)
            print()
         self.regs[self.regb] = self.mem[addr]
         self.iar += 1

      # LOAD [addr],Rx
      elif self.cmd == Computer.CMD_LOAD_IND_REG:
         addr = self.mem[self.byte_2]
         if addr == Computer.KBD:
            self.mem[Computer.KBD] = Computer.GetInput(self, 'Enter KBD Char: ', hex=False, char=True)
            print()
         self.regs[self.regb] = self.mem[addr]
         self.iar += 1

      # LOAD Rx,Ry
      elif self.cmd == Computer.CMD_LOAD_REG_REG:
         if self.regs[self.rega] == Computer.KBD:
            self.mem[Computer.KBD] = Computer.GetInput(self, 'Enter KBD Char: ', hex=False, char=True)
            print()
         self.regs[self.regb] = self.mem[self.regs[self.rega]]
         self.iar += 1

      # STORE Rx,addr
      elif self.cmd == Computer.CMD_STORE_MEM_REG:
         self.mem[self.byte_2] = self.regs[self.rega]
         if self.byte_2 == Computer.TTY:
            print(f'Displayed TTY Char: {chr(self.regs[self.rega])}\n')
         self.iar += 1

      # STORE Rx,Ry+IND
      elif self.cmd == Computer.CMD_STORE_IDX_REG:
         addr = self.regs[self.regb] + self.regs[self.IND]
         self.mem[addr] = self.regs[self.rega]
         if addr == Computer.TTY:
            print(f'Displayed TTY Char: {chr(self.regs[self.rega])}\n')
         self.iar += 1

      # STORE Rx,[addr]
      elif self.cmd == Computer.CMD_STORE_IND_REG:
         addr = self.mem[self.byte_2]
         self.mem[addr] = self.regs[self.rega]
         if addr == Computer.TTY:
            print(f'Displayed TTY Char: {chr(self.regs[self.rega])}\n')
         self.iar += 1

      # STORE Rx,Ry
      elif self.cmd == Computer.CMD_STORE_REG_REG:
         self.mem[self.regs[self.regb]] = self.regs[self.rega]
         if self.regs[self.regb] == Computer.TTY:
            print(f'Displayed TTY Char: {chr(self.regs[self.rega])}\n')
         self.iar += 1

      # JMP addr
      elif self.cmd == Computer.CMD_JMP_ADDR:
         self.iar = self.byte_2

      # JMP (addr)
      elif self.cmd == Computer.CMD_JMP_IND_MEM:
         self.iar = self.mem[self.byte_2]

      # JMP [Rx]
      elif self.cmd == Computer.CMD_JMP_IND_REG:
         self.iar = self.mem[self.regs[self.regb]]

      # JMP Rx
      elif self.cmd == Computer.CMD_JMP_REG:
         self.iar = self.regs[self.regb]

      # JSR addr
      elif self.cmd == Computer.CMD_JSR_MEM:
         # Push return address to the stack
         self.regs[Computer.SP] -= 1
         if self.regs[Computer.SP] < Computer.RAM_START:
            print('*** CRASH ***\nStack Overflow - Pushing to ROM\n')
            exit()
         self.iar += 1
         self.mem[self.regs[Computer.SP]] = self.iar
         # Go to addr
         self.iar = self.byte_2

      # JSR Rx+IND
      elif self.cmd == Computer.CMD_JSR_IDX:
         # Push return address to the stack
         self.regs[Computer.SP] -= 1
         if self.regs[Computer.SP] < Computer.RAM_START:
            print('*** CRASH ***\nStack Overflow - Pushing to ROM\n')
            exit()
         self.iar += 1
         self.mem[self.regs[Computer.SP]] = self.iar
         # Go to address in (Rx + IND)
         self.iar = self.regs[self.regb] + self.regs[Computer.IND]

      # JSR Rx
      elif self.cmd == Computer.CMD_JSR_REG:
         # Push return address to the stack
         self.regs[Computer.SP] -= 1
         if self.regs[Computer.SP] < Computer.RAM_START:
            print('*** CRASH ***\nStack Overflow - Pushing to ROM\n')
            exit()
         self.iar += 1
         self.mem[self.regs[Computer.SP]] = self.iar
         # Go to address in Rx
         self.iar = self.regs[self.regb]

      # PUSH #n / PUSH addrn
      elif self.cmd == Computer.CMD_PUSH_N:
         self.regs[Computer.SP] -= 1
         if self.regs[Computer.SP] < Computer.RAM_START:
            print('*** CRASH ***\nStack Overflow - Pushing to ROM\n')
            exit()
         self.mem[self.regs[Computer.SP]] = self.byte_2
         self.iar += 1

      # PUSH Rx
      elif self.cmd == Computer.CMD_PUSH_REG:
         self.regs[Computer.SP] -= 1
         if self.regs[Computer.SP] < Computer.RAM_START:
            print('*** CRASH ***\nStack Overflow - Pushing to ROM\n')
            exit()
         self.mem[self.regs[Computer.SP]] = self.regs[self.regb]
         self.iar += 1

      # PUSH (addr)
      elif self.cmd == Computer.CMD_PUSH_IND_MEM:
         self.regs[Computer.SP] -= 1
         if self.regs[Computer.SP] < Computer.RAM_START:
            print('*** CRASH ***\nStack Overflow - Pushing to ROM\n')
            exit()
         self.mem[self.regs[Computer.SP]] = self.mem[self.byte_2]
         self.iar += 1

      # POP addr
      elif self.cmd == Computer.CMD_POP_MEM:
         self.regs[Computer.FP] = None
         if self.regs[Computer.SP] >= Computer.IO_START:
            print('*** CRASH ***\nStack Underflow - Popping from I/O memory\n')
            exit()
         self.mem[self.byte_2] = self.mem[self.regs[Computer.SP]]
         self.regs[Computer.SP] += 1
         self.iar += 1

      # POP Rx
      elif self.cmd == Computer.CMD_POP_REG:
         if self.regs[Computer.SP] >= Computer.IO_START:
            print('*** CRASH ***\nStack Underflow - Popping from I/O memory\n')
            exit()
         self.regs[self.regb] = self.mem[self.regs[Computer.SP]]
         self.regs[Computer.SP] += 1
         self.iar += 1

      # POP [Rx]
      elif self.cmd == Computer.CMD_POP_IND_REG:
         self.regs[Computer.FP] = None
         if self.regs[Computer.SP] >= Computer.IO_START:
            print('*** CRASH ***\nStack Underflow - Popping from I/O memory\n')
            exit()
         ptr = self.regs[self.regb]
         self.mem[self.mem[ptr]] = self.mem[self.regs[Computer.SP]]
         self.regs[Computer.SP] += 1
         self.iar += 1

      # MOVE addr1,addr2
      elif self.cmd == Computer.CMD_MOVE_MEM_MEM:
         self.regs[Computer.FP] = None
         self.mem[self.byte_3] = self.mem[self.byte_2]
         self.iar += 1

      # MOVE Rx,Ry
      elif self.cmd == Computer.CMD_MOVE_REG_REG:
         self.regs[self.regb] = self.regs[self.rega]
         self.iar += 1

      # EXGR Rx,Ry
      elif self.cmd == Computer.CMD_EXGR:
         self.regs[self.rega], self.regs[self.regb] = self.regs[self.regb], self.regs[self.rega]
         self.iar += 1

      # SUB #n,addr
      elif self.cmd == Computer.CMD_SUB_N_MEM:
         self.regs[Computer.FP] = None
         res = self.byte_2 - self.mem[self.byte_3]
         Computer.SetFlags(self, res)
         if res < 0:
            self.flags[Computer.C] = True
            res += 0x10000
         self.mem[self.byte_3] = res
         self.iar += 1

      # SUB [Rx]+,Ry
      elif self.cmd == Computer.CMD_SUB_IND_POST_REG:
         ptr = self.regs[self.rega]
         res = self.mem[self.mem[ptr]] - self.regs[self.regb]
         Computer.SetFlags(self, res)
         if res < 0:
            self.flags[Computer.C] = True
            res += 0x10000
         self.regs[self.regb] = res
         self.mem[ptr] += 1
         self.iar += 1

      # ADD #n,Rx,Ry
      elif self.cmd == Computer.CMD_ADD_N_REG_REG:
         res = self.byte_2 + self.regs[self.rega]
         Computer.SetFlags(self, res)
         if res > 0xffff:
            res &= 0xffff
         self.regs[self.regb] = res
         self.iar += 1

      # ADD Rx,Ry
      elif self.cmd == Computer.CMD_ADD_REG_REG:
         res = self.regs[self.rega] + self.regs[self.regb]
         Computer.SetFlags(self, res)
         if res > 0xffff:
            res &= 0xffff
         self.regs[self.regb] = res
         self.iar += 1

      # ADD addr,Rx,Ry
      elif self.cmd == Computer.CMD_ADD_MEM_REG_REG:
         res = self.mem[self.byte_2] + self.regs[self.rega]
         Computer.SetFlags(self, res)
         if res > 0xffff:
            res &= 0xffff
         self.regs[self.regb] = res
         self.iar += 1

      # ADD [Rx]+,Ry
      elif self.cmd == Computer.CMD_ADD_IND_POST_REG:
         ptr = self.regs[self.rega]
         res = self.mem[self.mem[ptr]] + self.regs[self.regb]
         Computer.SetFlags(self, res)
         if res > 0xffff:
            res &= 0xffff
         self.regs[self.regb] = res
         self.mem[ptr] += 1
         self.iar += 1

      # SHR #n,Rx,Ry
      elif self.cmd == Computer.CMD_SHR_N_REG_REG:
         val = self.regs[self.rega]
         shift = self.byte_2

         res = val >> shift
         mask = (2**shift) - 1
         carry = val & mask
         
         Computer.SetFlags(self, res)
         self.flags[Computer.C] = False
         if carry >= 1:
            self.flags[Computer.C] = True
         self.regs[self.regb] = res
         self.iar += 1

      # SHR Rx,Ry
      elif self.cmd == Computer.CMD_SHR_REG_REG:
         val = self.regs[self.regb]
         shift = self.regs[self.rega]

         res = val >> shift
         mask = (2**shift) - 1
         carry = val & mask
         
         Computer.SetFlags(self, res)
         self.flags[Computer.C] = False
         if carry >= 1:
            self.flags[Computer.C] = True
         self.regs[self.regb] = res
         self.iar += 1

      # SHR #n,(Rx)
      elif self.cmd == Computer.CMD_SHR_N_IND:
         self.regs[Computer.FP] = None
         val = self.mem[self.regs[self.regb]]
         shift = self.byte_2

         res = val >> shift
         mask = (2**shift) - 1
         carry = val & mask
         
         Computer.SetFlags(self, res)
         self.flags[Computer.C] = False
         if carry >= 1:
            self.flags[Computer.C] = True
         self.mem[self.regs[self.regb]] = res
         self.iar += 1

      # SHL #n,Rx,Ry
      elif self.cmd == Computer.CMD_SHL_N_REG_REG:
         val = self.regs[self.rega]
         shift = self.byte_2

         res = val << shift
         mask = ((2**shift) - 1) << (16 - shift)
         carry = val & mask
         
         Computer.SetFlags(self, res)
         self.flags[Computer.C] = False
         if carry >= 1:
            self.flags[Computer.C] = True
         self.regs[self.regb] = res & 0xffff
         self.iar += 1

      # SHL Rx,Ry
      elif self.cmd == Computer.CMD_SHL_REG_REG:
         val = self.regs[self.regb]
         shift = self.regs[self.rega]

         res = val << shift
         mask = ((2**shift) - 1) << (16 - shift)
         carry = val & mask
         
         Computer.SetFlags(self, res)
         self.flags[Computer.C] = False
         if carry >= 1:
            self.flags[Computer.C] = True
         self.regs[self.regb] = res & 0xffff
         self.iar += 1

      # SHL #n,(Rx)
      elif self.cmd == Computer.CMD_SHL_N_IND:
         self.regs[Computer.FP] = None
         val = self.mem[self.regs[self.regb]]
         shift = self.byte_2

         res = val << shift
         mask = ((2**shift) - 1) << (16 - shift)
         carry = val & mask
         
         Computer.SetFlags(self, res)
         self.flags[Computer.C] = False
         if carry >= 1:
            self.flags[Computer.C] = True
         self.mem[self.regs[self.regb]] = res & 0xffff
         self.iar += 1

      # NOT addr
      elif self.cmd == Computer.CMD_NOT_MEM:
         res = (~self.mem[self.byte_2]) & 0xffff
         Computer.SetFlags(self, res)
         self.mem[self.byte_2] = res
         self.iar += 1

      # NOT Rx,Ry
      elif self.cmd == Computer.CMD_NOT_REG_REG:
         res = (~self.regs[self.rega]) & 0xffff
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res
         self.iar += 1

      # NOT Rx,(Ry)
      elif self.cmd == Computer.CMD_NOT_REG_IND:
         res = (~self.regs[self.rega]) & 0xffff
         Computer.SetFlags(self, res)
         self.mem[self.regs[self.regb]] = res
         self.iar += 1

      # AND #n,Rx,Ry
      elif self.cmd == Computer.CMD_AND_N_REG_REG:
         res = self.byte_2 & self.regs[self.rega]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res
         self.iar += 1

      # AND Rx,Ry
      elif self.cmd == Computer.CMD_AND_REG_REG:
         res = self.regs[self.rega] & self.regs[self.regb]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res
         self.iar += 1

      # AND addr,Rx,Ry
      elif self.cmd == Computer.CMD_AND_MEM_REG_REG:
         res = self.mem[self.byte_2] & self.regs[self.rega]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res
         self.iar += 1

      # AND [Rx]+,Ry
      elif self.cmd == Computer.CMD_AND_IND_POST_REG:
         ptr = self.regs[self.rega]
         res = self.mem[self.mem[ptr]] & self.regs[self.regb]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res
         self.mem[ptr] += 1
         self.iar += 1

      # OR #n,Rx,Ry
      elif self.cmd == Computer.CMD_OR_N_REG_REG:
         res = self.byte_2 | self.regs[self.rega]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res
         self.iar += 1

      # OR Rx,Ry
      elif self.cmd == Computer.CMD_OR_REG_REG:
         res = self.regs[self.rega] | self.regs[self.regb]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res
         self.iar += 1

      # OR addr,Rx,Ry
      elif self.cmd == Computer.CMD_OR_MEM_REG_REG:
         res = self.mem[self.byte_2] | self.regs[self.rega]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res
         self.iar += 1

      # OR [Rx]+,Ry
      elif self.cmd == Computer.CMD_OR_IND_POST_REG:
         ptr = self.regs[self.rega]
         res = self.mem[self.mem[ptr]] | self.regs[self.regb]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res
         self.mem[ptr] += 1
         self.iar += 1

      # XOR #n,Rx,Ry
      elif self.cmd == Computer.CMD_XOR_N_REG_REG:
         res = self.byte_2 ^ self.regs[self.rega]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res
         self.iar += 1

      # XOR Rx,Ry
      elif self.cmd == Computer.CMD_XOR_REG_REG:
         res = self.regs[self.rega] ^ self.regs[self.regb]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res
         self.iar += 1

      # XOR addr,Rx,Ry
      elif self.cmd == Computer.CMD_XOR_MEM_REG_REG:
         res = self.mem[self.byte_2] ^ self.regs[self.rega]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res
         self.iar += 1

      # XOR [Rx]+,Ry
      elif self.cmd == Computer.CMD_XOR_IND_POST_REG:
         ptr = self.regs[self.rega]
         res = self.mem[self.mem[ptr]] ^ self.regs[self.regb]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res
         self.mem[ptr] += 1
         self.iar += 1

      # CMP #n,Rx / FCOMP #n,Rx
      elif self.cmd in [Computer.CMD_CMP_N_REG, Computer.CMD_FCOMP_N_REG]:
         res = 0x0001
         Computer.SetFlags(self, res)
         self.iar += 1

      # CMP Rx,Ry / FCOMP Rx,Ry
      elif self.cmd in [Computer.CMD_CMP_REG_REG, Computer.CMD_FCOMP_REG_REG]:
         res = 0x0001
         Computer.SetFlags(self, res)
         self.iar += 1

      # CMP addr,Rx / FCOMP addr,Rx
      elif self.cmd in [Computer.CMD_CMP_MEM_REG, Computer.CMD_FCOMP_MEM_REG]:
         res = 0x0001
         Computer.SetFlags(self, res)
         self.iar += 1

      # CMP addr1,addr2 / FCOMP addr1,addr2
      elif self.cmd in [Computer.CMD_CMP_MEM_MEM, Computer.CMD_FCOMP_MEM_MEM]:
         res = 0x0001
         Computer.SetFlags(self, res)
         self.iar += 1

      # INC Rx
      elif self.cmd == Computer.CMD_INC_REG:
         res = self.regs[self.regb] + 1
         Computer.SetFlags(self, res)
         if res > 0xffff:
            res = 0x0000
         self.regs[self.regb] = res
         self.iar += 1

      # INC addr
      elif self.cmd == Computer.CMD_INC_MEM:
         res = self.mem[self.byte_2] + 1
         Computer.SetFlags(self, res)
         if res > 0xffff:
            res = 0x0000
         self.mem[self.byte_2] = res
         self.iar += 1

      # DEC Rx
      elif self.cmd == Computer.CMD_DEC_REG:
         res = self.regs[self.regb] - 1
         Computer.SetFlags(self, res)
         if res < 0:
            res = 0xffff
         self.regs[self.regb] = res
         self.iar += 1

      # DEC addr
      elif self.cmd == Computer.CMD_DEC_MEM:
         res = self.mem[self.byte_2] - 1
         Computer.SetFlags(self, res)
         if res < 0:
            res = 0xffff
         self.mem[self.byte_2] = res
         self.iar += 1

      # JUMPIF addr / JUMPIF Rx
      elif self.cmd in [Computer.CMD_JUMPIF_MEM, Computer.CMD_JUMPIF_REG]:
         jump = False 
         if (self.cond == Computer.JC) and self.flags[Computer.C]:
               jump = True
         elif (self.cond == Computer.JAGT) and self.flags[Computer.A]:
               jump = True
         elif (self.cond == Computer.JCA) and self.flags[Computer.A] and self.flags[Computer.C]:
               jump = True
         elif (self.cond == Computer.JE) and self.flags[Computer.E]:
               jump = True
         elif (self.cond == Computer.JCE) and self.flags[Computer.C] and self.flags[Computer.E]:
               jump = True
         elif (self.cond == Computer.JAGE) and (self.flags[Computer.A] or self.flags[Computer.E]):
               jump = True
         elif (self.cond == Computer.JALE) and (self.flags[Computer.E] or not self.flags[Computer.A]):
               jump = True
         elif (self.cond == Computer.JZ) and self.flags[Computer.Z]:
               jump = True
         elif (self.cond == Computer.JMIN) and not self.flags[Computer.Z] and self.flags[Computer.N]:
               jump = True
         elif (self.cond == Computer.JEZ) and self.flags[Computer.E] and self.flags[Computer.Z]:
               jump = True
         elif (self.cond == Computer.JNE) and not self.flags[Computer.E]:
               jump = True
         elif (self.cond == Computer.JPOS) and not self.flags[Computer.Z] and not self.flags[Computer.N]:
               jump = True
         elif (self.cond == Computer.JNC) and not self.flags[Computer.C]:
               jump = True
         elif (self.cond == Computer.JNZ) and not self.flags[Computer.Z]:
               jump = True
         elif (self.cond == Computer.JALT) and not self.flags[Computer.E] and not self.flags[Computer.A]:
               jump = True
         if jump:
            if self.cmd == Computer.CMD_JUMPIF_MEM:
               self.iar = self.byte_2
            else:
               self.iar = self.regs[self.regb]
         else:
            self.iar += 1

      # EXGM addr1,addr2
      elif self.cmd == Computer.CMD_EXGM:
         self.regs[Computer.FP] = None
         self.mem[self.byte_2], self.mem[self.byte_3] = self.mem[self.byte_3], self.mem[self.byte_2]
         self.iar += 1

      # CLF
      elif self.cmd == Computer.CMD_CLF:
         for i in range(len(self.flags)):
            self.flags[i] = False
         self.iar += 1

      # END
      elif self.cmd == Computer.CMD_END:
         self.state = Computer.ST_END

      # SUB #n,Rx,Ry
      elif self.cmd == Computer.CMD_SUB_N_REG_REG:
         res = self.byte_2 - self.regs[self.rega]
         Computer.SetFlags(self, res)
         if res < 0:
            self.flags[Computer.C] = True
            res += 0x10000
         self.regs[self.regb] = res
         self.iar += 1

      # SUB Rx,Ry
      elif self.cmd == Computer.CMD_SUB_REG_REG:
         res = self.regs[self.rega] - self.regs[self.regb]
         Computer.SetFlags(self, res)
         if res < 0:
            self.flags[Computer.C] = True
            res += 0x10000
         self.regs[self.regb] = res
         self.iar += 1

      # SUB addr,Rx,Ry
      elif self.cmd == Computer.CMD_SUB_MEM_REG_REG:
         res = self.mem[self.byte_2] - self.regs[self.rega]
         Computer.SetFlags(self, res)
         if res < 0:
            self.flags[Computer.C] = True
            res += 0x10000
         self.regs[self.regb] = res
         self.iar += 1

      # SUB addr1,addr2
      elif self.cmd == Computer.CMD_SUB_MEM_MEM:
         self.regs[Computer.FP] = None
         res = self.mem[self.byte_2] - self.mem[self.byte_3]
         Computer.SetFlags(self, res)
         if res < 0:
            self.flags[Computer.C] = True
            res += 0x10000
         self.mem[self.byte_3] = res
         self.iar += 1

      # MULT #n,Rx,Ry
      elif self.cmd == Computer.CMD_MULT_N_REG_REG:
         res = self.byte_2 * self.regs[self.rega]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res & 0xffff
         self.iar += 1

      # MULT Rx,Ry
      elif self.cmd == Computer.CMD_MULT_REG_REG:
         res = self.regs[self.rega] * self.regs[self.regb]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res & 0xffff
         self.iar += 1

      # MULT addr,Rx,Ry
      elif self.cmd == Computer.CMD_MULT_MEM_REG_REG:
         res = self.mem[self.byte_2] * self.regs[self.rega]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res & 0xffff
         self.iar += 1

      # MULT [Rx]+,Ry
      elif self.cmd == Computer.CMD_MULT_IND_POST_REG:
         ptr = self.regs[self.rega]
         res = self.mem[self.mem[ptr]] * self.regs[self.regb]
         Computer.SetFlags(self, res)
         self.regs[self.regb] = res & 0xffff
         self.mem[ptr] += 1
         self.iar += 1

      # DIV #n,Rx,Ry
      elif self.cmd == Computer.CMD_DIV_N_REG_REG:
         self.regs[Computer.FP] = None
         x = self.byte_2
         if x > 0x7fff:
            x -= 0x10000

         y = self.regs[self.rega]
         if y > 0x7fff:
            y -= 0x10000

         if y == 0:
            # Logisim Divider gives: x / 0 = x rem 0
            quot = x
            rem = 0
         else:
            quot = int(x/y)
            if quot < 0:
               quot += 0x10000
            rem = x - (quot * y)

         Computer.SetFlags(self, rem)
         self.regs[self.rega] = quot & 0xffff
         self.regs[self.regb] = rem & 0xffff
         self.iar += 1

      # DIV Rx,Ry
      elif self.cmd == Computer.CMD_DIV_REG_REG:
         x = self.regs[self.rega]
         if x > 0x7fff:
            x -= 0x10000

         y = self.regs[self.regb]
         if y > 0x7fff:
            y -= 0x10000

         if y == 0:
            # Logisim Divider gives: x / 0 = x rem 0
            quot = x
            rem = 0
         else:
            quot = int(x/y)
            if quot < 0:
               quot += 0x10000
            rem = x - (quot * y)

         Computer.SetFlags(self, rem)
         self.regs[self.rega] = quot & 0xffff
         self.regs[self.regb] = rem & 0xffff
         self.iar += 1

      # RET
      elif self.cmd == Computer.CMD_RET:
         # Pop return address from the stack
         if self.regs[Computer.SP] >= Computer.IO_START:
            print('*** CRASH ***\nStack Underflow - Popping from I/O memory\n')
            exit()
         self.iar = self.mem[self.regs[Computer.SP]]
         self.regs[Computer.SP] += 1

      # CLR Rx
      elif self.cmd == Computer.CMD_CLR:
         self.regs[self.regb] = 0x0000
         self.iar += 1

      # SPLASH addr
      elif self.cmd == Computer.CMD_SPLASH:
         print("Ignoring the SPLASH command as it's redundant within the Emulator ...\n")
         self.iar += 1

      # PIXEL addr,Rx,Ry
      elif self.cmd == Computer.CMD_PIXEL:
         pos = self.regs[self.regb]
         self.gr_mem[pos] = self.regs[self.rega]
         self.iar += 1

      # STORE Rx,n+Ry
      elif self.cmd == Computer.CMD_STORE_REG_OFF_REG:
         addr = self.byte_2 + self.regs[self.regb]
         self.mem[addr] = self.regs[self.rega]
         if addr == Computer.TTY:
            print(f'Displayed TTY Char: {chr(self.regs[self.rega])}\n')
         self.iar += 1

      # LOAD n+Rx,Ry
      elif self.cmd == Computer.CMD_LOAD_OFF_REG_REG:
         addr = self.byte_2 + self.regs[self.rega]
         if addr == Computer.KBD:
            self.mem[Computer.KBD] = Computer.GetInput(self, 'Enter KBD Char: ', hex=False, char=True)
            print()
         self.regs[self.regb] = self.mem[addr]
         self.iar += 1

      # FMULT #n,Rx,Ry
      elif self.cmd == Computer.CMD_FMULT_N_REG_REG:
         res = self.fpu.calculate(FPU.MULTIPLY, self.byte_2, self.regs[self.rega])
         self.regs[self.regb] = res
         self.iar += 1

      # FMULT Rx,Ry
      elif self.cmd == Computer.CMD_FMULT_REG_REG:
         res = self.fpu.calculate(FPU.MULTIPLY, self.regs[self.rega], self.regs[self.regb])
         self.regs[self.regb] = res
         self.iar += 1

      # FMULT addr,Rx,Ry
      elif self.cmd == Computer.CMD_FMULT_MEM_REG_REG:
         res = self.fpu.calculate(FPU.MULTIPLY, self.mem[self.byte_2], self.regs[self.rega])
         self.regs[self.regb] = res
         self.iar += 1

      # FMULT addr1,addr2
      elif self.cmd == Computer.CMD_FMULT_MEM_MEM:
         self.regs[Computer.FP] = None
         res = self.fpu.calculate(FPU.MULTIPLY, self.mem[self.byte_2], self.mem[self.byte_3])
         self.mem[self.byte_3] = res
         self.iar += 1

      # FADD #n,Rx,Ry
      elif self.cmd == Computer.CMD_FADD_N_REG_REG:
         res = self.fpu.calculate(FPU.ADD, self.byte_2, self.regs[self.rega])
         self.regs[self.regb] = res
         self.iar += 1

      # FADD Rx,Ry
      elif self.cmd == Computer.CMD_FADD_REG_REG:
         res = self.fpu.calculate(FPU.ADD, self.regs[self.rega], self.regs[self.regb])
         self.regs[self.regb] = res
         self.iar += 1

      # FADD addr,Rx,Ry
      elif self.cmd == Computer.CMD_FADD_MEM_REG_REG:
         res = self.fpu.calculate(FPU.ADD, self.mem[self.byte_2], self.regs[self.rega])
         self.regs[self.regb] = res
         self.iar += 1

      # FADD addr1,addr2
      elif self.cmd == Computer.CMD_FADD_MEM_MEM:
         self.regs[Computer.FP] = None
         res = self.fpu.calculate(FPU.ADD, self.mem[self.byte_2], self.mem[self.byte_3])
         self.mem[self.byte_3] = res
         self.iar += 1

      # FSUB #n,Rx,Ry
      elif self.cmd == Computer.CMD_FSUB_N_REG_REG:
         res = self.fpu.calculate(FPU.SUBTRACT, self.byte_2, self.regs[self.rega])
         self.regs[self.regb] = res
         self.iar += 1

      # FSUB Rx,Ry
      elif self.cmd == Computer.CMD_FSUB_REG_REG:
         res = self.fpu.calculate(FPU.SUBTRACT, self.regs[self.rega], self.regs[self.regb])
         self.regs[self.regb] = res
         self.iar += 1

      # FSUB addr,Rx,Ry
      elif self.cmd == Computer.CMD_FSUB_MEM_REG_REG:
         res = self.fpu.calculate(FPU.SUBTRACT, self.mem[self.byte_2], self.regs[self.rega])
         self.regs[self.regb] = res
         self.iar += 1

      # FSUB addr1,addr2
      elif self.cmd == Computer.CMD_FSUB_MEM_MEM:
         self.regs[Computer.FP] = None
         res = self.fpu.calculate(FPU.SUBTRACT, self.mem[self.byte_2], self.mem[self.byte_3])
         self.mem[self.byte_3] = res
         self.iar += 1

      # FDIV #n,Rx,Ry
      elif self.cmd == Computer.CMD_FDIV_N_REG_REG:
         res = self.fpu.calculate(FPU.DIVIDE, self.byte_2, self.regs[self.rega])
         self.regs[self.regb] = res
         self.iar += 1

      # FDIV Rx,Ry
      elif self.cmd == Computer.CMD_FDIV_REG_REG:
         res = self.fpu.calculate(FPU.DIVIDE, self.regs[self.rega], self.regs[self.regb])
         self.regs[self.regb] = res
         self.iar += 1

      # FDIV addr,Rx,Ry
      elif self.cmd == Computer.CMD_FDIV_MEM_REG_REG:
         res = self.fpu.calculate(FPU.DIVIDE, self.mem[self.byte_2], self.regs[self.rega])
         self.regs[self.regb] = res
         self.iar += 1

      # FDIV addr1,addr2
      elif self.cmd == Computer.CMD_FDIV_MEM_MEM:
         self.regs[Computer.FP] = None
         res = self.fpu.calculate(FPU.DIVIDE, self.mem[self.byte_2], self.mem[self.byte_3])
         self.mem[self.byte_3] = res
         self.iar += 1

      # FSQRT #n,Ry
      elif self.cmd == Computer.CMD_FSQRT_N_REG:
         res = self.fpu.calculate(FPU.SQRT, self.byte_2)
         self.regs[self.regb] = res
         self.iar += 1

      # FSQRT Rx,Ry
      elif self.cmd == Computer.CMD_FSQRT_REG_REG:
         res = self.fpu.calculate(FPU.SQRT, self.regs[self.rega])
         self.regs[self.regb] = res
         self.iar += 1

      # FSQRT addr,Ry
      elif self.cmd == Computer.CMD_FSQRT_MEM_REG:
         res = self.fpu.calculate(FPU.SQRT, self.mem[self.byte_2])
         self.regs[self.regb] = res
         self.iar += 1

      # FSQRT addr1,addr2
      elif self.cmd == Computer.CMD_FSQRT_MEM_MEM:
         self.regs[Computer.FP] = None
         res = self.fpu.calculate(FPU.SQRT, self.mem[self.byte_2])
         self.mem[self.byte_3] = res
         self.iar += 1

