
import json

# Create a Microcode dictionary
with open('./Microcode/Microcode.json', 'r') as f:
    microcode_dict = json.load(f)

# Check the Microcode's all good
errors_found = False
for instr, modes in microcode_dict.items():
    for mode, steps in modes.items():
        for step in steps:
            if len(step) != 8 or not all(c in '0123456789ABCDEFabcdef' for c in step):
                print(f"Invalid step '{step}' in instruction {instr}, mode {mode}")
                errors_found = True

if errors_found:
    exit(0)  

# Flatten microcode
hex_flat = []
sequencer = []
counter = 0

for instr in microcode_dict:
    for mode in ['0', '1', '2', '3']:
        steps = microcode_dict[instr].get(mode, [])
        for word in steps:
            hex_flat.append(word)
        if steps:
            sequencer.append(f'{counter:03X}')
            counter += len(steps)

total_values = len(hex_flat)
required_values = 64 * 16
if total_values < required_values:
    hex_flat.extend(['00000000'] * (required_values - total_values))

with open('./Microcode/Microcode.uc', 'w') as f:
    f.write('v3.0 hex words addressed\n')
    for i in range(0, len(hex_flat), 8):
        line = ' '.join(hex_flat[i:i+8])
        f.write(f'{i:03x}: {line}\n')

with open('./Microcode/MicrocodeLUT.uc', 'w') as f:
    f.write('v3.0 hex words addressed\n')
    for i in range(0, len(sequencer), 16):
        row = sequencer[i:i+16]
        f.write(f'{i:02x}: {" ".join(row)}\n')
    print("Microcode generated successfully.")
